# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all

block_cipher = None

# Thu thập toàn bộ binaries + datas + imports của curl_cffi
cffi_datas, cffi_binaries, cffi_hiddenimports = collect_all('curl_cffi')

a = Analysis(
    ['app.py'],
    pathex=[],
    binaries=cffi_binaries,
    datas=[
        ('version.json', '.'),
    ] + cffi_datas,
    hiddenimports=[
        'curl_cffi',
        'curl_cffi.requests',
        'curl_cffi._wrapper',
    ] + cffi_hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['pymongo', 'dns', 'dnspython', 'bson'],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='Veo3',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    version='version_info.txt',
)

